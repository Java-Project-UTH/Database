﻿CREATE DATABASE Pickleball___BookingSystem;
GO

USE Pickleball_BookingSystem;
GO

CREATE TABLE Nguoi_Dung(
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(50) UNIQUE NOT NULL,
    password_hash NVARCHAR(255) NOT NULL,
    full_name NVARCHAR(100) NOT NULL,
    email NVARCHAR(100) UNIQUE NOT NULL,
    phone_number NVARCHAR(20) NULL,
    role NVARCHAR(10) CHECK (role IN ('admin', 'user')) DEFAULT 'user',
    created_at DATETIME DEFAULT GETDATE()
);

CREATE TABLE Dem_ (
    court_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(50) NOT NULL,
    location NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    price_per_hour DECIMAL(10, 2) NOT NULL,
    status NVARCHAR(20) CHECK (status IN ('available', 'maintenance')) DEFAULT 'available'
);

CREATE TABLE Dat_San (
    booking_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    court_id INT NOT NULL,
    booking_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status NVARCHAR(20) CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')) DEFAULT 'pending',
    created_at DATETIME DEFAULT GETDATE(),

    FOREIGN KEY (user_id) REFERENCES Nguoi_Dung(user_id),
    FOREIGN KEY (court_id) REFERENCES Dem_(court_id)
);

CREATE TABLE Thanh_Toan (
    payment_id INT IDENTITY(1,1) PRIMARY KEY,
    booking_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_method NVARCHAR(20) CHECK (payment_method IN ('credit_card', 'momo', 'bank_transfer', 'cash')) NOT NULL,
    payment_status NVARCHAR(20) CHECK (payment_status IN ('pending', 'paid', 'failed')) DEFAULT 'pending',
    payment_date DATETIME DEFAULT GETDATE(),

    FOREIGN KEY (booking_id) REFERENCES Dat_San(booking_id)
);

CREATE TABLE Bao_Tri (
    schedule_id INT IDENTITY(1,1) PRIMARY KEY,
    court_id INT NOT NULL,
    maintenance_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    description NVARCHAR(MAX) NULL,

    FOREIGN KEY (court_id) REFERENCES Dem_(court_id)
);

CREATE TABLE Danh_Gia (
    review_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    court_id INT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5) NOT NULL,
    comment NVARCHAR(MAX) NULL,
    created_at DATETIME DEFAULT GETDATE(),

    FOREIGN KEY (user_id) REFERENCES Nguoi_Dung(user_id),
    FOREIGN KEY (court_id) REFERENCES Dem_(court_id)
);

INSERT INTO Nguoi_Dung(username, password_hash, full_name, email, phone_number, role)
VALUES 
('admin1', 'hashed_password_1', N'Admin User', 'admin1@example.com', '0901234567', 'admin'),
('user1', 'hashed_password_2', N'Nguyễn Văn A', 'user1@example.com', '0912345678', 'user'),
('user2', 'hashed_password_3', N'Trần Thị B', 'user2@example.com', '0923456789', 'user');

INSERT INTO Dem_(name, location, description, price_per_hour, status)
VALUES 
(N'Sân 1', N'123 Lý Thường Kiệt, Quận 10, TP.HCM', N'Sân tiêu chuẩn, có đèn đêm', 200000, 'available'),
(N'Sân 2', N'456 Nguyễn Trãi, Quận 5, TP.HCM', N'Sân trong nhà, có máy lạnh', 300000, 'available'),
(N'Sân 3', N'789 CMT8, Quận 3, TP.HCM', N'Sân ngoài trời, rộng rãi', 150000, 'maintenance');

INSERT INTO Dat_San(user_id, court_id, booking_date, start_time, end_time, total_price, status)
VALUES
(2, 1, '2025-03-25', '08:00', '10:00', 400000, 'confirmed'),
(3, 2, '2025-03-26', '18:00', '20:00', 600000, 'pending');

INSERT INTO Bao_Tri(court_id, maintenance_date, start_time, end_time, description)
VALUES
(3, '2025-03-27', '09:00', '12:00', N'Bảo trì mặt sân và hệ thống chiếu sáng');

INSERT INTO Danh_Gia(user_id, court_id, rating, comment)
VALUES
(2, 1, 5, N'Sân rất tốt, phục vụ nhiệt tình'),
(3, 2, 4, N'Sân ổn, nhưng giá hơi cao');

